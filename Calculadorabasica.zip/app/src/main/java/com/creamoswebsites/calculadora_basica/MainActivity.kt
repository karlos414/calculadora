package com.creamoswebsites.calculadora_basica

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {

    //VARIABLES
    var pantalla:EditText?=null
    var operador1:Double=0.0
    var operador2:Double=0.0
    var respuesta:Double=0.0

    //VARIABLE QUE IDENTIFICA EL OPERADOR A USAR
    /*
    * 1=SUMA
    * 2=RESTA
    * 3=MULTIPLICACION
    * 4=DIVISION
    * 5=RAIZ
    * 6=EXPONENCIAL
    * 7=SIN
    * 8=COS
    * 9=TAN
    * 10=CSC
    * 11=SEC
    * 12=CTG
    */
    var ope:Int=0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //MENSAJE DE BIENVENIDA
        Toast.makeText(this, "Bienvenido a la calculadora", Toast.LENGTH_LONG).show()

        pantalla = findViewById<EditText>(R.id.caja)


        // CLICKS LISTENERS DE LOS BOTONES
        btn1.setOnClickListener(){
            btn1()
        }

        btn2.setOnClickListener(){
            btn2()
        }

        btn3.setOnClickListener(){
            btn3()
        }

        btn4.setOnClickListener(){
            btn4()
        }

        btn5.setOnClickListener(){
            btn5()
        }

        btn6.setOnClickListener(){
            btn6()
        }

        btn7.setOnClickListener(){
            btn7()
        }

        btn8.setOnClickListener(){
            btn8()
        }

        btn9.setOnClickListener(){
            btn9()
        }

        btn0.setOnClickListener(){
            btn0()
        }

        btnpunto.setOnClickListener(){
            btnpunto()
        }


        // CLICK LISTENER OPERADORES
        btnsuma.setOnClickListener(){
            suma()
        }

        btnresta.setOnClickListener(){
            resta()
        }

        btnmultiplicacion.setOnClickListener(){
            multiplicacion()
        }

        btndivision.setOnClickListener(){
            division()
        }

        btnraiz.setOnClickListener(){
            raiz()
        }

        btnexponente.setOnClickListener(){
            exponencial()
        }

        btnsin.setOnClickListener(){
            sin()
        }

        btncos.setOnClickListener(){
            cos()
        }

        btntan.setOnClickListener(){
            tan()
        }

        btnCsc.setOnClickListener(){
            csc()
        }

        btnsec.setOnClickListener(){
            sec()
        }

        btnctg.setOnClickListener(){
            ctg()
        }

        // CLICK LISTENER RESULTADO
        btnigual.setOnClickListener(){
            igual()
        }

        // CLICK LISTENER LIMPIAR Y BORRAR
        btnborrar.setOnClickListener(){
            borrar()
        }

        btnlimpiar.setOnClickListener(){
            limpiar()
        }

    }



    // FUNCIONES DE LOS BOTONES NUMERICOS
    fun btn1(){
        var cap:String = pantalla?.getText().toString()
        cap+="1"
        pantalla!!.setText(cap)
    }

    fun btn2(){
        var cap:String = pantalla?.getText().toString()
        cap+="2"
        pantalla!!.setText(cap)
    }

    fun btn3(){
        var cap:String = pantalla?.getText().toString()
        cap+="3"
        pantalla!!.setText(cap)
    }

    fun btn4(){
        var cap:String = pantalla?.getText().toString()
        cap+="4"
        pantalla!!.setText(cap)
    }

    fun btn5(){
        var cap:String = pantalla?.getText().toString()
        cap+="5"
        pantalla!!.setText(cap)
    }

    fun btn6(){
        var cap:String = pantalla?.getText().toString()
        cap+="6"
        pantalla!!.setText(cap)
    }

    fun btn7(){
        var cap:String = pantalla?.getText().toString()
        cap+="7"
        pantalla!!.setText(cap)
    }

    fun btn8(){
        var cap:String = pantalla?.getText().toString()
        cap+="8"
        pantalla!!.setText(cap)
    }

    fun btn9(){
        var cap:String = pantalla?.getText().toString()
        cap+="9"
        pantalla!!.setText(cap)
    }

    fun btn0(){
        var cap:String = pantalla?.getText().toString()
        cap+="0"
        pantalla!!.setText(cap)
    }

    fun btnpunto(){
        var cap:String = pantalla?.getText().toString()
        cap+="."
        pantalla!!.setText(cap)
    }

    //FUNCIONES OPERADORES
    fun suma(){

        //VALIDACION DE ERRORES
        try {
            val aux1:String = pantalla?.getText().toString()
            operador1 = aux1.toDouble()
        }catch(e: NumberFormatException){}
        pantalla?.setText("")
        ope=1

    }

    fun resta(){

        //VALIDACION DE ERRORES
        try {
            val aux1:String = pantalla?.getText().toString()
            operador1 = aux1.toDouble()
        }catch(e: NumberFormatException){}
        pantalla?.setText("")
        ope=2
    }

    fun multiplicacion(){

        //VALIDACION DE ERRORES
        try {
            val aux1:String = pantalla?.getText().toString()
            operador1 = aux1.toDouble()
        }catch(e: NumberFormatException){}
        pantalla?.setText("")
        ope=3
    }

    fun division(){
        //VALIDACION DE ERRORES
        try {
            val aux1:String = pantalla?.getText().toString()
            operador1 = aux1.toDouble()
        }catch(e: NumberFormatException){}
        pantalla?.setText("")
        ope=4
    }

    fun raiz(){

        //VALIDAR ERRORES
        try {
            val aux1:String =   pantalla?.getText().toString()
            operador1= aux1.toDouble()
        }catch (e: NumberFormatException){}
        pantalla?.setText("√("+operador1+")")
        ope=5
    }

    fun exponencial(){

        //VALIDAR ERRORES
        try {
            val aux1:String =   pantalla?.getText().toString()
            operador1= aux1.toDouble()
        }catch (e: NumberFormatException){}
        pantalla?.setText("")
        ope=6
    }

    fun sin(){

        //VALIDAR ERRORES
        try {
            val aux1:String =   pantalla?.getText().toString()
            operador1= aux1.toDouble()
        }catch (e: NumberFormatException){}
        pantalla?.setText("Sin("+operador1+")")
        ope=7
    }

    fun cos(){

        //VALIDAR ERRORES
        try {
            val aux1:String =   pantalla?.getText().toString()
            operador1= aux1.toDouble()
        }catch (e: NumberFormatException){}
        pantalla?.setText("Cos("+operador1+")")
        ope=8
    }

    fun tan(){

        //VALIDAR ERRORES
        try {
            val aux1:String =   pantalla?.getText().toString()
            operador1= aux1.toDouble()
        }catch (e: NumberFormatException){}
        pantalla?.setText("Tan("+operador1+")")
        ope=9
    }

    fun csc(){

        //VALIDAR ERRORES
        try {
            val aux1:String =   pantalla?.getText().toString()
            operador1= aux1.toDouble()
        }catch (e: NumberFormatException){}
        pantalla?.setText("Csc("+operador1+")")
        ope=10
    }

    fun sec(){

        //VALIDAR ERRORES
        try {
            val aux1:String =   pantalla?.getText().toString()
            operador1= aux1.toDouble()
        }catch (e: NumberFormatException){}
        pantalla?.setText("Sin("+operador1+")")
        ope=11
    }

    fun ctg(){

        //VALIDAR ERRORES
        try {
            val aux1:String =   pantalla?.getText().toString()
            operador1= aux1.toDouble()
        }catch (e: NumberFormatException){}
        pantalla?.setText("Sin("+operador1+")")
        ope=12
    }

    //FUNCION RESULTADO
    fun igual(){

        //VALIDAR ERRORES
        try {
            val aux2:String = pantalla?.getText().toString()
            operador2 = aux2.toDouble()
        }catch (e: NumberFormatException){}
        pantalla?.setText("")


        /*
        * 1=SUMA
        * 2=RESTA
        * 3=MULTIPLICACION
        * 4=DIVISION
        * 5=RAIZ
        * 6=EXPONENCIAL
        * 7=SIN
        * 8=COS
        * 9=TAN
        * 10=CSC
        * 11=SEC
        * 12=CTG
        */
        //SELECCION DE OPERACION A REALIZAR
        when(ope){
            1 -> respuesta=operador1+operador2
            2 -> respuesta=operador1-operador2
            3 -> respuesta=operador1*operador2
            4 -> if (operador2.toInt()==(0)){
                Toast.makeText(this, "No se puede dividir por 0", Toast.LENGTH_LONG).show()
            }
            else {
                respuesta = operador1 / operador2
            }
            5 -> respuesta = Math.sqrt(operador1)
            6 -> respuesta = Math.pow(operador1,operador2)
            7 -> {
                val rad:Double = Math.toRadians(operador1)
                respuesta = Math.sin(rad)
            }
            8 -> {
                val rad:Double = Math.toRadians(operador1)
                respuesta = Math.cos(rad)
            }
            9 -> {
                val rad:Double = Math.toRadians(operador1)
                respuesta = Math.tan(rad)
            }
            10 -> {
                val angulo:Double = Math.acos(operador1)
                respuesta = Math.toDegrees(angulo)
            }
            11 -> {
                val angulo:Double = Math.asin(operador1)
                respuesta = Math.toDegrees(angulo)
            }
            12 -> {
                val angulo:Double = Math.atan(operador1)
                respuesta = Math.toDegrees(angulo)
            }
        }

        //IMPRIMIR LA RESPUESTA EN LA PANTALLA
        pantalla?.setText(""+respuesta)
        operador1=respuesta

    }

    //FUNCIONES LIMPIAR
    fun limpiar(){
        pantalla?.setText("")
        operador1=0.0
        operador2=0.0
        respuesta=0.0
    }

    //SABER LONGITUD DE INGRESO Y RESTAR EL ULTIMO DIGITO INGRESADO
    fun borrar(){
        if (!pantalla?.getText().toString().equals("")){
            pantalla!!.setText(pantalla!!.getText().subSequence(0, pantalla!!.getText().length-1))
        }
    }


}
